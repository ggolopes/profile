function parallax(elem,intensity){
 
  intensity = typeof intensity === "undefined" ? 2 : intensity;
   
  ws = (window.pageYOffset || document.documentElement.scrollTop) - (document.documentElement.clientTop || 0);
  wsPos = ws/intensity;
 
  if($(elem).length > 1){ 
    $(elem).each(function(){
      elemPos = $(this).position().top/intensity;
      $(this).css({backgroundPosition: "0px "+(wsPos - elemPos)+"px"})
    })
  } else {
    elemPos = $(elem).position().top/intensity;
    $(elem).css({backgroundPosition: "0px "+(elem == "body" ? wsPos : wsPos - elemPos)+"px"})
  }
}


$(document).ready(function(){
  parallax("section.parallax:nth-child(1)");
  parallax("section:nth-child(5), 10");
});
 
$(window).scroll(function(){
  parallax("section.parallax:nth-child(1)");
  parallax("section:nth-child(5), 10");
});

const menuItems = document.querySelectorAll('.navOptions a[href^="#"]');
console.log(menuItems);